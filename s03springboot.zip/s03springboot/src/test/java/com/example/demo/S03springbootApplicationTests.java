package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S03springbootmvcApplicationTests {

	@Test
	void contextLoads() {
	}

}